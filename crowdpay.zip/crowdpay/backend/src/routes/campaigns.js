const router = require('express').Router();
const multer = require('multer');
const Sentry = require('@sentry/node');
const db = require('../config/database');
const logger = require('../config/logger');
const { MILESTONE_LIMIT } = require('../config/constants');
const { requireAuth, requireRole } = require('../middleware/auth');
const {
  createCampaignWallet,
  getCampaignBalance,
  getSupportedAssetCodes,
  revokeAndCloseCampaignWallet,
} = require('../services/stellarService');
const { sendAlert } = require('../services/alerting');
const cache = require('../utils/cache');
const { Keypair } = require('@stellar/stellar-sdk');
const { encryptSecret } = require('../services/walletService');
const { watchCampaignWallet, addSSEClient, removeSSEClient } = require('../services/ledgerMonitor');
const { emitWebhookEventForUser, WEBHOOK_EVENTS } = require('../services/webhookDispatcher');
const { refreshCampaignStatus, refreshActiveCampaignStatuses } = require('../services/campaignStatusService');
const { queueFailedCampaignRefunds } = require('../services/campaignStatusActions');
const {
  invokeContract,
  encodeMilestone,
  nativeToScVal,
  deployCampaignContracts,
  getContractStatus,
} = require('../services/sorobanService');
const { sendEmail, sendTeamMemberInvitedEmail } = require('../services/emailService');
const { uploadCampaignCoverImage } = require('../services/storage');
const { isKycRequiredForCampaigns } = require('../services/kycProvider');
const { listCreatorCampaigns } = require('../services/userDashboardService');
const { publishDraftCampaign, CampaignNotPublishableError } = require('../services/campaignPublishing');
const {
  MAX_TIERS_PER_CAMPAIGN,
  validateTiersInput,
  insertTiers,
  listTiersWithAvailability,
} = require('../services/rewardTierService');
const { streamCampaignContributionExport } = require('../services/contributionExportService');
const {
  createCampaignValidation,
  createCampaignUpdateValidation,
  getCampaignsValidation,
  validateRequest,
} = require('../middleware/validation');
const asyncHandler = require('../utils/asyncHandler');
const {
  createCampaignInvite,
  resendCampaignInvite,
  cancelCampaignInvite,
  acceptCampaignInvite,
  countAcceptedOwners,
  resolveUserCampaignRole,
} = require('../services/campaignInviteService');
const {
  isValidRole,
  canEditCampaignContent,
  canViewAnalytics,
  canInviteMembers,
  canManageMembers,
  canChangeRoles,
} = require('../lib/campaignPermissions');
const { stripHtml } = require('../lib/sanitize');
const { getSimhash, simhashSimilarity } = require('../utils/simhash');
const { parsePagination } = require('../utils/pagination');

const crypto = require('crypto');

async function generateUniqueReferralCode(runner = db) {
  for (let i = 0; i < 10; i++) {
    const code = crypto.randomBytes(6).toString('base64url').slice(0, 8);
    const { rows } = await runner.query(
      'SELECT 1 FROM campaign_referrals WHERE referral_code = $1',
      [code]
    );
    if (!rows.length) return code;
  }
  throw new Error('Could not generate unique referral code');
}

/**
 * @openapi
 * tags:
 *   - name: Campaigns
 *     description: Campaign discovery and management
 */

const requireCampaignMember = (...allowedRoles) => {
  return asyncHandler(async (req, res, next) => {
    const campaignId = req.params.id || req.params.campaign_id || req.body.campaign_id;
    if (!campaignId) return res.status(400).json({ error: 'Campaign ID is required' });

    if (!req.user || !req.user.userId) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    const { rows: campaignRows } = await db.query(
      'SELECT creator_id FROM campaigns WHERE id = $1',
      [campaignId]
    );
    if (!campaignRows.length) {
      return res.status(404).json({ error: 'Campaign not found' });
    }
    const campaign = campaignRows[0];

    if (req.user.role === 'admin') {
      req.campaignRole = 'owner';
      return next();
    }

    const { rows: memberRows } = await db.query(
      'SELECT role, accepted_at FROM campaign_members WHERE campaign_id = $1 AND user_id = $2',
      [campaignId, req.user.userId]
    );

    let role = null;
    if (memberRows.length && memberRows[0].accepted_at) {
      role = memberRows[0].role;
    } else if (campaign.creator_id === req.user.userId) {
      role = 'owner';
    }

    if (!role || (allowedRoles.length && !allowedRoles.includes(role))) {
      return res.status(403).json({ error: 'Insufficient permissions for this campaign' });
    }

    req.campaignRole = role;
    next();
  });
};

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const allowed = ['image/jpeg', 'image/png', 'image/webp'];
    if (!allowed.includes(file.mimetype)) {
      return cb(new Error('Invalid image type. Only JPG, PNG and WEBP are allowed.'));
    }
    cb(null, true);
  },
});

const SUPPORTED_ASSETS = getSupportedAssetCodes();
const MILESTONE_PERCENT_SCALE = 10000;

function normalizeMilestonesInput(input) {
  if (input === null || input === undefined) return [];
  if (!Array.isArray(input)) {
    throw new Error('milestones must be an array');
  }
  if (input.length === 0) return [];
  if (input.length > MILESTONE_LIMIT) {
    throw new Error(`Campaigns can define at most ${MILESTONE_LIMIT} milestones`);
  }

  const normalized = input.map((milestone, index) => {
    const title = stripHtml(milestone?.title || '');
    const description = stripHtml(milestone?.description || '');
    if (!title) {
      throw new Error(`Milestone ${index + 1} title is required`);
    }
    if (!description) {
      throw new Error(`Milestone ${index + 1} description is required`);
    }

    const releasePercentage = Number(milestone?.release_percentage);
    if (!Number.isFinite(releasePercentage) || releasePercentage <= 0) {
      throw new Error(`Milestone ${index + 1} release_percentage must be greater than zero`);
    }

    return {
      title,
      description,
      release_percentage: releasePercentage.toFixed(4),
      release_percentage_units: Math.round(releasePercentage * MILESTONE_PERCENT_SCALE),
      sort_order: index,
    };
  });

  const totalUnits = normalized.reduce((sum, milestone) => sum + milestone.release_percentage_units, 0);
  const expectedUnits = 100 * MILESTONE_PERCENT_SCALE;
  if (totalUnits > expectedUnits) {
    throw new Error('Milestone percentages must not exceed 100%');
  }
  if (totalUnits < expectedUnits) {
    throw new Error('Milestone percentages must sum to at least 100%');
  }

  return normalized;
}

// List campaigns with optional search, filtering, sorting, and pagination
router.get('/', getCampaignsValidation, validateRequest, asyncHandler(async (req, res) => {
  /**
   * @openapi
   * /api/campaigns:
   *   get:
   *     tags: [Campaigns]
   *     summary: List campaigns
   *     parameters:
   *       - in: query
   *         name: status
   *         schema: { type: string }
   *       - in: query
   *         name: asset
   *         schema: { type: string }
   *       - in: query
   *         name: search
   *         schema: { type: string }
   *       - in: query
   *         name: sort
   *         schema: { type: string }
   *       - in: query
   *         name: limit
   *         schema: { type: integer, minimum: 1, maximum: 50 }
   *       - in: query
   *         name: offset
   *         schema: { type: integer, minimum: 0 }
   *     responses:
   *       200:
   *         description: OK
   *         content:
   *           application/json:
   *             schema:
   *               type: object
   *               properties:
   *                 total: { type: integer }
   *                 limit: { type: integer }
   *                 offset: { type: integer }
   *                 campaigns:
   *                   type: array
   *                   items:
   *                     type: object
   */
  const { search, status, asset, category, min_progress, sort = 'newest' } = req.query;
  const limit = Math.min(Number(req.query.limit || 20), 100);
  const offset = Math.max(Number(req.query.offset || 0), 0);
  const filters = [];
  const params = [];

  // Exclude deleted and hidden campaigns from public listing
  filters.push(`c.deleted_at IS NULL`);
  filters.push(`c.is_flagged_duplicate = FALSE`);
  filters.push(`c.is_hidden = FALSE`);

  if (status) {
    params.push(status);
    filters.push(`c.status = $${params.length}`);
  } else {
    filters.push(`c.status = 'active'`);
  }
  if (asset) {
    params.push(asset);
    filters.push(`c.asset_type = $${params.length}`);
  }
  if (category) {
    params.push(category);
    filters.push(`c.category = $${params.length}`);
  }
  if (min_progress) {
    params.push(Number(min_progress));
    // Progress is (raised_amount / target_amount) * 100
    filters.push(`(c.raised_amount / c.target_amount) * 100 >= $${params.length}`);
  }
  let searchParamIdx = null;
  if (search) {
    params.push(search);
    searchParamIdx = params.length;
    filters.push(`c.search_vector @@ websearch_to_tsquery('english', $${params.length})`);
  }

  const whereClause = filters.length ? `WHERE ${filters.join(' AND ')}` : '';
  const countQuery = `SELECT COUNT(*)::int AS total FROM campaigns c ${whereClause}`;
  const countResult = await db.query(countQuery, params);
  const total = countResult.rows[0]?.total || 0;

  const sortExpressions = {
    newest: 'c.created_at DESC',
    trending: `(SELECT COUNT(*) FROM contributions ctr WHERE ctr.campaign_id = c.id AND ctr.created_at >= NOW() - INTERVAL '48 hours') DESC`,
    ending_soon: 'c.deadline ASC NULLS LAST',
    most_funded: 'c.raised_amount DESC',
    most_backed: '(SELECT COUNT(*) FROM contributions ctr WHERE ctr.campaign_id = c.id) DESC',
    closest_to_goal: '(c.raised_amount / NULLIF(c.target_amount, 0)) DESC NULLS LAST, c.raised_amount DESC',
  };
  if (searchParamIdx !== null) {
    sortExpressions.relevance = `ts_rank(c.search_vector, websearch_to_tsquery('english', $${searchParamIdx})) DESC, c.created_at DESC`;
  }
  // A search without an explicit sort ranks by relevance; explicit sorts always win.
  const effectiveSort =
    searchParamIdx !== null && req.query.sort === undefined ? 'relevance' : sort;
  const orderBy = sortExpressions[effectiveSort] || sortExpressions.newest;

  const query = `
    SELECT c.*,
           u.name AS creator_name,
           u.kyc_status AS creator_kyc_status,
           (SELECT COUNT(*)::int FROM campaign_updates cu WHERE cu.campaign_id = c.id) AS updates_count,
           (SELECT COUNT(DISTINCT sender_public_key)::int FROM contributions con WHERE con.campaign_id = c.id) AS contributor_count
    FROM campaigns c
    JOIN users u ON u.id = c.creator_id
    ${whereClause}
    ORDER BY ${orderBy}
    LIMIT $${params.length + 1}
    OFFSET $${params.length + 2}
  `;
  const result = await db.query(query, [...params, limit, offset]);

  res.json({ total, limit, offset, campaigns: result.rows });
}));

router.get('/mine', requireAuth, asyncHandler(async (req, res) => {
  const { page, limit } = req.query;
  const result = await listCreatorCampaigns(req.user.userId, { page, limit });
  res.json(result);
}));

router.get('/:id/milestones', asyncHandler(async (req, res) => {
  const { rows } = await db.query(
    `SELECT m.*, (c.milestones_contract_id IS NOT NULL) AS on_chain
     FROM milestones m
     JOIN campaigns c ON c.id = m.campaign_id
     WHERE m.campaign_id = $1
     ORDER BY m.sort_order ASC, m.created_at ASC`,
    [req.params.id]
  );
  res.json(rows);
}));

router.post('/:id/milestones', requireAuth, requireCampaignMember('owner'), asyncHandler(async (req, res) => {
  let normalizedMilestones;
  try {
    normalizedMilestones = normalizeMilestonesInput(req.body?.milestones);
  } catch (err) {
    return res.status(400).json({ error: err.message });
  }

  if (!normalizedMilestones.length) {
    return res.status(400).json({ error: 'At least one milestone is required' });
  }

  const client = await db.connect();
  try {
    await client.query('BEGIN');
    const { rows: campaignRows } = await client.query(
      'SELECT id, creator_id, status FROM campaigns WHERE id = $1 FOR UPDATE',
      [req.params.id]
    );
    if (!campaignRows.length) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'Campaign not found' });
    }
    const campaign = campaignRows[0];
    if (campaign.creator_id !== req.user.userId) {
      await client.query('ROLLBACK');
      return res.status(403).json({ error: 'Only the campaign creator can define milestones' });
    }
    if (!['active', 'funded', 'in_progress'].includes(campaign.status)) {
      await client.query('ROLLBACK');
      return res.status(409).json({ error: `Milestones cannot be edited while campaign status is "${campaign.status}".` });
    }

    const { rows: existingRows } = await client.query(
      'SELECT status FROM milestones WHERE campaign_id = $1',
      [campaign.id]
    );
    if (existingRows.some((row) => row.status !== 'pending')) {
      await client.query('ROLLBACK');
      return res.status(409).json({ error: 'Milestone plan cannot be changed after approvals or releases begin' });
    }

    await client.query('DELETE FROM milestones WHERE campaign_id = $1', [campaign.id]);
    const inserted = [];
    for (const milestone of normalizedMilestones) {
      const { rows } = await client.query(
        `INSERT INTO milestones
           (campaign_id, title, description, release_percentage, sort_order)
         VALUES ($1, $2, $3, $4, $5)
         RETURNING *`,
        [
          campaign.id,
          milestone.title,
          milestone.description,
          milestone.release_percentage,
          milestone.sort_order,
        ]
      );
      inserted.push(rows[0]);
    }
    await client.query('COMMIT');
    res.status(201).json(inserted);
  } catch (err) {
    await client.query('ROLLBACK');
    logger.error('Campaign milestone plan update failed', { campaign_id: req.params.id, error: err.message });
    res.status(500).json({ error: 'Could not save campaign milestones' });
  } finally {
    client.release();
  }
}));

router.get('/:id/clone-data', requireAuth, requireCampaignMember('owner'), asyncHandler(async (req, res) => {
  const campaignId = req.params.id;

  const { rows: campaignRows } = await db.query(
    `SELECT title, description, target_amount, asset_type, category, min_contribution, max_contribution, max_per_user, show_backer_amounts
     FROM campaigns 
     WHERE id = $1`,
    [campaignId]
  );

  if (!campaignRows.length) {
    return res.status(404).json({ error: 'Campaign not found' });
  }

  const campaign = campaignRows[0];

  const { rows: milestones } = await db.query(
    `SELECT title, description, release_percentage
     FROM milestones 
     WHERE campaign_id = $1 
     ORDER BY sort_order ASC`,
    [campaignId]
  );

  const { rows: reward_tiers } = await db.query(
    `SELECT title, description, min_amount, "limit", estimated_delivery
     FROM reward_tiers 
     WHERE campaign_id = $1
     ORDER BY min_amount ASC`,
    [campaignId]
  );

  res.json({
    title: `Copy of ${campaign.title}`,
    description: campaign.description,
    target_amount: campaign.target_amount,
    asset_type: campaign.asset_type,
    category: campaign.category,
    min_contribution: campaign.min_contribution,
    max_contribution: campaign.max_contribution,
    max_per_user: campaign.max_per_user,
    show_backer_amounts: campaign.show_backer_amounts,
    milestones: milestones,
    reward_tiers: reward_tiers
  });
}));

// One-click clone: copies fields, milestones, and reward tiers into a new
// draft campaign with no on-chain wallet/contracts yet (instant, no gas cost).
router.post('/:id/clone', requireAuth, requireCampaignMember('owner'), asyncHandler(async (req, res) => {
  const sourceId = req.params.id;

  const { rows: campaignRows } = await db.query(
    `SELECT title, description, target_amount, asset_type, category,
            min_contribution, max_contribution, max_per_user, show_backer_amounts
     FROM campaigns WHERE id = $1`,
    [sourceId]
  );
  if (!campaignRows.length) return res.status(404).json({ error: 'Campaign not found' });
  const source = campaignRows[0];

  const { rows: milestoneRows } = await db.query(
    'SELECT title, description, release_percentage, sort_order FROM milestones WHERE campaign_id = $1 ORDER BY sort_order ASC',
    [sourceId]
  );
  const { rows: tierRows } = await db.query(
    'SELECT title, description, min_amount, asset_type, tier_limit, estimated_delivery FROM reward_tiers WHERE campaign_id = $1 ORDER BY min_amount ASC',
    [sourceId]
  );

  const { rows: userRows } = await db.query('SELECT email FROM users WHERE id = $1', [req.user.userId]);
  const creatorEmail = userRows[0]?.email;

  const client = await db.connect();
  let clone;
  try {
    await client.query('BEGIN');

    const { rows } = await client.query(
      `INSERT INTO campaigns
         (title, description, target_amount, asset_type, creator_id, status,
          category, min_contribution, max_contribution, max_per_user, show_backer_amounts,
          raised_amount, cloned_from)
       VALUES ($1, $2, $3, $4, $5, 'draft', $6, $7, $8, $9, $10, 0, $11)
       RETURNING *`,
      [
        `${source.title} (Copy)`,
        source.description,
        source.target_amount,
        source.asset_type,
        req.user.userId,
        source.category,
        source.min_contribution,
        source.max_contribution,
        source.max_per_user,
        source.show_backer_amounts,
        sourceId,
      ]
    );
    clone = rows[0];

    await client.query(
      `INSERT INTO campaign_members (campaign_id, user_id, email, role, accepted_at)
       VALUES ($1, $2, $3, 'owner', NOW())`,
      [clone.id, req.user.userId, creatorEmail]
    );

    for (const milestone of milestoneRows) {
      await client.query(
        `INSERT INTO milestones (campaign_id, title, description, release_percentage, sort_order)
         VALUES ($1, $2, $3, $4, $5)`,
        [clone.id, milestone.title, milestone.description, milestone.release_percentage, milestone.sort_order]
      );
    }

    if (tierRows.length) {
      await insertTiers(
        client,
        clone.id,
        tierRows.map((t) => ({
          title: t.title,
          description: t.description,
          min_amount: t.min_amount,
          asset_type: t.asset_type,
          tier_limit: t.tier_limit,
          estimated_delivery: t.estimated_delivery,
        }))
      );
    }

    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK');
    logger.error('[campaigns] clone failed', { source_campaign_id: sourceId, error: err.message });
    return res.status(500).json({ error: 'Could not clone campaign' });
  } finally {
    client.release();
  }

  res.status(201).json(clone);
}));

// Schedule (or clear) auto-publish for a draft campaign.
router.post('/:id/schedule-publish', requireAuth, requireCampaignMember('owner'), asyncHandler(async (req, res) => {
  const { scheduled_publish_at } = req.body || {};

  const { rows: campaignRows } = await db.query('SELECT status FROM campaigns WHERE id = $1', [req.params.id]);
  if (!campaignRows.length) return res.status(404).json({ error: 'Campaign not found' });
  if (campaignRows[0].status !== 'draft') {
    return res.status(409).json({ error: 'Only draft campaigns can be scheduled for publishing' });
  }

  let value = null;
  if (scheduled_publish_at) {
    const date = new Date(scheduled_publish_at);
    if (isNaN(date.getTime())) {
      return res.status(422).json({ error: 'scheduled_publish_at must be a valid ISO 8601 date' });
    }
    if (date.getTime() <= Date.now()) {
      return res.status(422).json({ error: 'scheduled_publish_at must be in the future' });
    }
    value = date.toISOString();
  }

  const { rows } = await db.query(
    'UPDATE campaigns SET scheduled_publish_at = $1 WHERE id = $2 RETURNING *',
    [value, req.params.id]
  );
  res.json(rows[0]);
}));

// Deploy the on-chain wallet + contracts for a draft campaign and make it active.
router.post('/:id/publish', requireAuth, requireCampaignMember('owner'), asyncHandler(async (req, res) => {
  try {
    const campaign = await publishDraftCampaign(req.params.id);
    res.json(campaign);
  } catch (err) {
    if (err instanceof CampaignNotPublishableError) {
      return res.status(409).json({ error: err.message });
    }
    logger.error('[campaigns] publish failed', { campaign_id: req.params.id, error: err.message });
    res.status(502).json({ error: 'Could not publish campaign', detail: err.message });
  }
}));

// Get single Campaign
// Get featured campaigns
router.get('/featured', asyncHandler(async (req, res) => {
  const { rows } = await db.query(`
    SELECT c.id, c.title, c.description, c.target_amount, c.raised_amount,
           c.asset_type, c.status, c.deadline, c.featured_note,
           u.name AS creator_name,
           (SELECT COUNT(*) FROM contributions WHERE campaign_id = c.id) AS contributor_count
    FROM campaigns c
    JOIN users u ON u.id = c.creator_id
    WHERE c.featured = TRUE AND c.status = 'active' AND c.deleted_at IS NULL AND c.is_flagged_duplicate = FALSE AND c.is_hidden = FALSE
    ORDER BY c.featured_at DESC
    LIMIT 3
  `);
  res.json(rows);
}));

// Add campaign to the current user's favorites/wishlist
router.post('/:id/favorite', requireAuth, asyncHandler(async (req, res) => {
  const { rows: campaigns } = await db.query('SELECT id FROM campaigns WHERE id = $1', [req.params.id]);
  if (!campaigns.length) return res.status(404).json({ error: 'Campaign not found' });

  await db.query(
    `INSERT INTO contributor_favorites (user_id, campaign_id)
     VALUES ($1, $2)
     ON CONFLICT (user_id, campaign_id) DO NOTHING`,
    [req.user.userId, req.params.id]
  );
  res.status(204).send();
}));

// DELETE /campaigns/:id — Soft-delete campaign (owner only) and revoke/close Stellar wallet
router.delete('/:id', requireAuth, requireCampaignMember('owner'), asyncHandler(async (req, res) => {
  const { id } = req.params;

  const { rows: campaignRows } = await db.query(
    'SELECT id, title, creator_id, wallet_public_key, wallet_secret_encrypted FROM campaigns WHERE id = $1 AND deleted_at IS NULL',
    [id]
  );

  if (!campaignRows.length) {
    return res.status(404).json({ error: 'Campaign not found' });
  }

  const campaign = campaignRows[0];

  // Revoke platform multisig, sweep non-zero funds to platform, and close Stellar account
  try {
    await revokeAndCloseCampaignWallet(campaign);
  } catch (stellarErr) {
    logger.error('Failed to revoke platform multisig / close Stellar account for deleted campaign', {
      campaignId: id,
      error: stellarErr.message,
    });
    await sendAlert('Campaign wallet cleanup failed on deletion', {
      campaignId: id,
      walletPublicKey: campaign.wallet_public_key,
      error: stellarErr.message,
    });
    return res.status(502).json({
      error: 'Failed to revoke Stellar wallet multisig and close account',
      details: stellarErr.message,
    });
  }

  const { rows: updated } = await db.query(
    `UPDATE campaigns SET deleted_at = NOW() WHERE id = $1 RETURNING id, title, deleted_at`,
    [id]
  );

  logger.info('Campaign deleted by owner', { campaignId: id, userId: req.user.userId });
  cache.invalidate(`campaigns:id:${id}`);
  cache.invalidatePrefix('campaigns:list:');
  res.json({ message: 'Campaign deleted', campaign: updated[0] });
}));

// Remove campaign from the current user's favorites/wishlist
router.delete('/:id/favorite', requireAuth, asyncHandler(async (req, res) => {
  await db.query(
    'DELETE FROM contributor_favorites WHERE user_id = $1 AND campaign_id = $2',
    [req.user.userId, req.params.id]
  );
  res.status(204).send();
}));

router.get('/categories', asyncHandler(async (req, res) => {
  const { rows } = await db.query(`
    SELECT category, COUNT(*)::int AS count
    FROM campaigns
    WHERE status = 'active' AND deleted_at IS NULL AND is_flagged_duplicate = FALSE AND is_hidden = FALSE
    GROUP BY category
    ORDER BY category ASC
  `);
  res.json(rows);
}));

router.get('/:id/contract-status', asyncHandler(async (req, res) => {
  const { rows } = await db.query(
    `SELECT id, contract_address, escrow_contract_id, milestones_contract_id,
            target_amount, deadline, status,
            contract_deployment_status, contract_deployment_error
     FROM campaigns
     WHERE id = $1`,
    [req.params.id]
  );

  if (!rows.length) {
    return res.status(404).json({ error: 'Campaign not found' });
  }

  const campaign = rows[0];
  const escrowContractId = campaign.escrow_contract_id || campaign.contract_address;

  if (!escrowContractId && !campaign.milestones_contract_id) {
    return res.json({
      has_contract: false,
      contract_deployment_status: campaign.contract_deployment_status,
      contract_deployment_error: campaign.contract_deployment_error,
      status: campaign.status,
      totalRaised: 0,
      milestones: [],
    });
  }

  try {
    const deadlineUnix = campaign.deadline
      ? Math.floor(new Date(campaign.deadline).getTime() / 1000)
      : 0;
    const targetAmount = Math.floor(Number(campaign.target_amount) * 10_000_000);

    const onChain = await getContractStatus({
      escrowContractId,
      milestonesContractId: campaign.milestones_contract_id,
      deadlineUnix,
      targetAmount,
    });

    res.json({
      has_contract: true,
      contract_address: campaign.contract_address || escrowContractId,
      escrow_contract_id: escrowContractId,
      milestones_contract_id: campaign.milestones_contract_id,
      contract_deployment_status: campaign.contract_deployment_status,
      ...onChain,
    });
  } catch (err) {
    logger.error('Failed to read on-chain contract status', {
      campaign_id: req.params.id,
      error: err.message,
    });
    res.status(502).json({
      error: 'Could not read on-chain contract status',
      detail: err.message,
    });
  }
}));

router.get('/:id', asyncHandler(async (req, res) => {
  /**
   * @openapi
   * /api/campaigns/{id}:
   *   get:
   *     tags: [Campaigns]
   *     summary: Get campaign by id
   *     parameters:
   *       - in: path
   *         name: id
   *         required: true
   *         schema: { type: string }
   *     responses:
   *       200:
   *         description: OK
   *       404:
   *         description: Not found
   */
  const refCode = req.query.ref;
  if (refCode) {
    try {
      const { rows: referralRows } = await db.query(
        'SELECT id, campaign_id FROM campaign_referrals WHERE referral_code = $1 AND campaign_id = $2',
        [refCode, req.params.id]
      );
      if (referralRows.length) {
        await db.query(
          'UPDATE campaign_referrals SET click_count = click_count + 1 WHERE id = $1',
          [referralRows[0].id]
        );
        res.cookie(`cp_ref_${req.params.id}`, refCode, {
          httpOnly: true,
          sameSite: 'lax',
          maxAge: 30 * 24 * 60 * 60 * 1000,
          path: '/',
        });
      }
    } catch (err) {
      logger.warn('Referral click tracking failed', { campaign_id: req.params.id, ref: refCode, error: err.message });
    }
  }

  const query = `
    SELECT *,
           (SELECT COUNT(DISTINCT sender_public_key)::int FROM contributions WHERE campaign_id = $1) AS contributor_count
    FROM campaigns
    WHERE id = $1
  `;
  await refreshCampaignStatus(req.params.id);
  const { rows } = await db.query(query, [req.params.id]);
  if (!rows.length) return res.status(404).json({ error: 'Campaign not found' });
  
  const campaign = rows[0];
  
  // Allow viewing suspended campaigns with a notice, but deleted campaigns are not accessible
  if (campaign.deleted_at) {
    return res.status(404).json({ error: 'Campaign not found' });
  }

  let userRole = null;

  const header = req.headers.authorization;
  const token =
    req.cookies?.cp_token ||
    (header && header.startsWith('Bearer ') ? header.slice(7).trim() : null);
  if (token && !token.startsWith('cp_live_') && !token.startsWith('cpk_')) {
    try {
      const jwt = require('jsonwebtoken');
      const payload = jwt.verify(token, process.env.JWT_SECRET);
      if (payload && payload.userId) {
        if (payload.is_admin) {
          userRole = 'owner';
        } else if (campaign.creator_id === payload.userId) {
          userRole = 'owner';
        } else {
          userRole = await resolveUserCampaignRole(
            campaign.id,
            payload.userId,
            payload.role === 'admin'
          );
        }
      }
    } catch (err) {
      // Ignore invalid token for public route
    }
  }

  // Hidden campaigns only accessible by owner or admin
  if (campaign.is_hidden && userRole !== 'owner') {
    return res.status(404).json({ error: 'Campaign not found' });
  }

  // Add notice if campaign is suspended
  const response = { ...campaign, user_role: userRole };
  if (campaign.status === 'suspended') {
    response.suspended_notice = 'This campaign has been suspended and cannot receive new contributions';
  }

  res.json(response);
}));

function daysRemaining(deadline) {
  if (!deadline) return null;
  const end = new Date(deadline);
  end.setHours(23, 59, 59, 999);
  return Math.max(0, Math.ceil((end.getTime() - Date.now()) / (1000 * 60 * 60 * 24)));
}

async function loadPublicCampaignSummary(campaignId) {
  const { rows } = await db.query(
    `SELECT id, title, description, target_amount, raised_amount, asset_type, status, deadline,
            (SELECT COUNT(*)::int FROM contributions c WHERE c.campaign_id = campaigns.id) AS backer_count
     FROM campaigns WHERE id = $1 AND deleted_at IS NULL AND is_hidden = FALSE`,
    [campaignId]
  );
  if (!rows.length) return null;

  const campaign = rows[0];
  const pct = campaign.target_amount
    ? Math.min(100, (Number(campaign.raised_amount) / Number(campaign.target_amount)) * 100)
    : 0;

  return {
    id: campaign.id,
    title: campaign.title,
    description: campaign.description,
    raised_amount: Number(campaign.raised_amount),
    target_amount: Number(campaign.target_amount),
    asset_type: campaign.asset_type,
    status: campaign.status,
    deadline: campaign.deadline,
    backer_count: campaign.backer_count,
    days_remaining: daysRemaining(campaign.deadline),
    progress_percentage: Math.round(pct * 10) / 10,
    contribution_url: `${process.env.FRONTEND_URL || 'http://localhost:5173'}/campaigns/${campaign.id}`,
  };
}

// The embed widget speaks in four milestone states (#596). Internally a
// milestone awaiting platform review is `pending_review`, and a rejected one is
// back in the creator's hands, so both collapse to a public-facing state.
const EMBED_MILESTONE_STATUS = {
  pending: 'pending',
  rejected: 'pending',
  pending_review: 'submitted',
  approved: 'approved',
  released: 'released',
};

async function loadPublicCampaignMilestones(campaignId) {
  const { rows } = await db.query(
    `SELECT id, title, release_percentage, sort_order, status
     FROM milestones
     WHERE campaign_id = $1
     ORDER BY sort_order ASC, created_at ASC`,
    [campaignId]
  );

  return rows.map((milestone) => ({
    id: milestone.id,
    title: milestone.title,
    release_percentage: Number(milestone.release_percentage),
    sort_order: milestone.sort_order,
    status: EMBED_MILESTONE_STATUS[milestone.status] || 'pending',
  }));
}

function summariseMilestones(milestones) {
  const released = milestones.filter((milestone) => milestone.status === 'released');
  const releasedPercentage = released.reduce(
    (total, milestone) => total + milestone.release_percentage,
    0
  );

  return {
    total: milestones.length,
    released: released.length,
    approved: milestones.filter((milestone) => milestone.status === 'approved').length,
    submitted: milestones.filter((milestone) => milestone.status === 'submitted').length,
    pending: milestones.filter((milestone) => milestone.status === 'pending').length,
    released_percentage: Math.round(releasedPercentage * 10) / 10,
  };
}

function escapeXml(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function buildFundingBadgeSvg({ leftLabel, rightLabel }) {
  const leftWidth = Math.max(72, leftLabel.length * 7 + 18);
  const rightWidth = Math.max(100, rightLabel.length * 6.5 + 18);
  const totalWidth = leftWidth + rightWidth;

  return [
    `<svg xmlns="http://www.w3.org/2000/svg" width="${totalWidth}" height="20" role="img" aria-label="${escapeXml(`${leftLabel}: ${rightLabel}`)}">`,
    `<linearGradient id="g" x2="0" y2="100%"><stop offset="0" stop-color="#fbfbfb"/><stop offset="1" stop-color="#f0f0f0"/></linearGradient>`,
    `<clipPath id="c"><rect width="${totalWidth}" height="20" rx="3" fill="#fff"/></clipPath>`,
    `<g clip-path="url(#c)">`,
    `<rect width="${leftWidth}" height="20" fill="#555"/>`,
    `<rect x="${leftWidth}" width="${rightWidth}" height="20" fill="#7c3aed"/>`,
    `<rect width="${totalWidth}" height="20" fill="url(#g)"/>`,
    `<g fill="#fff" text-anchor="middle" font-family="Verdana,Geneva,DejaVu Sans,sans-serif" text-rendering="geometricPrecision" font-size="11">`,
    `<text x="${leftWidth / 2}" y="14">${escapeXml(leftLabel)}</text>`,
    `<text x="${leftWidth + rightWidth / 2}" y="14">${escapeXml(rightLabel)}</text>`,
    `</g></g></svg>`,
  ].join('');
}

// Embeddable campaign widget data (public, with permissive CORS)
router.get('/:id/embed', asyncHandler(async (req, res) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET');
  res.header('Access-Control-Allow-Headers', 'Content-Type');

  const campaignId = req.params.id;
  const summary = await loadPublicCampaignSummary(campaignId);
  if (!summary) return res.status(404).json({ error: 'Campaign not found' });

  const milestones = await loadPublicCampaignMilestones(campaignId);

  res.json({
    ...summary,
    description:
      summary.description?.slice(0, 200) + (summary.description?.length > 200 ? '...' : ''),
    milestones,
    milestone_summary: summariseMilestones(milestones),
  });
}));

// Compact widget payload for lightweight iframe embeds
router.get('/:id/widget', asyncHandler(async (req, res) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET');
  res.header('Access-Control-Allow-Headers', 'Content-Type');

  const campaignId = req.params.id;
  const summary = await loadPublicCampaignSummary(campaignId);
  if (!summary) return res.status(404).json({ error: 'Campaign not found' });

  const milestones = await loadPublicCampaignMilestones(campaignId);

  res.json({
    id: summary.id,
    title: summary.title,
    raised_amount: summary.raised_amount,
    target_amount: summary.target_amount,
    asset_type: summary.asset_type,
    status: summary.status,
    contributor_count: summary.backer_count,
    days_remaining: summary.days_remaining,
    progress_percentage: summary.progress_percentage,
    contribution_url: summary.contribution_url,
    milestones,
    milestone_summary: summariseMilestones(milestones),
  });
}));

// SVG funding badge for README embedding (shields.io style)
router.get('/:id/badge.svg', asyncHandler(async (req, res) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Cache-Control', 'no-cache, no-store, must-revalidate');

  const campaignId = parseInt(req.params.id, 10);
  const summary = await loadPublicCampaignSummary(campaignId);
  if (!summary) return res.status(404).send('Campaign not found');

  const raisedLabel = `${summary.raised_amount.toLocaleString()} / ${summary.target_amount.toLocaleString()} ${summary.asset_type}`;
  const rightLabel = `${summary.progress_percentage}% · ${raisedLabel}`;
  const svg = buildFundingBadgeSvg({ leftLabel: 'CrowdPay', rightLabel });

  res.type('image/svg+xml').send(svg);
}));

// Get backers for a campaign
router.get('/:id/backers', asyncHandler(async (req, res) => {
  const campaignId = req.params.id;
  const { rows: campaignRows } = await db.query('SELECT show_backer_amounts FROM campaigns WHERE id = $1', [campaignId]);
  if (!campaignRows.length) return res.status(404).json({ error: 'Campaign not found' });
  const { show_backer_amounts } = campaignRows[0];

  const { limit, offset } = parsePagination(req.query, { limit: 20, max: 100 });

  const countResult = await db.query(
    'SELECT COUNT(*)::int AS total FROM contributions WHERE campaign_id = $1',
    [campaignId]
  );
  const total = countResult.rows[0].total;

  const query = `
    SELECT 
      display_name,
      sender_public_key,
      ${show_backer_amounts ? 'amount,' : ''}
      asset,
      created_at
    FROM contributions
    WHERE campaign_id = $1
    ORDER BY created_at DESC
    LIMIT $2 OFFSET $3
  `;
  const { rows } = await db.query(query, [campaignId, limit, offset]);
  res.json({ data: rows, total, limit, offset });
}));

// Download contributor fulfillment data for campaign owners/admins.
router.get('/:id/contributions/export', requireAuth, requireCampaignMember('owner'), asyncHandler(async (req, res) => {
  await streamCampaignContributionExport({
    campaignId: req.params.id,
    res,
    runner: db,
  });
}));

// SSE stream for real-time campaign funding updates
router.get('/:id/stream', asyncHandler(async (req, res) => {
  const campaignId = parseInt(req.params.id, 10);
  const { rows } = await db.query('SELECT id FROM campaigns WHERE id = $1', [campaignId]);
  if (!rows.length) return res.status(404).json({ error: 'Campaign not found' });

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders();

  res.write('data: {"type":"connected"}\n\n');

  addSSEClient(campaignId, res);

  const heartbeat = setInterval(() => {
    try {
      res.write(': heartbeat\n\n');
    } catch {
      clearInterval(heartbeat);
    }
  }, 25000);

  req.on('close', () => {
    clearInterval(heartbeat);
    removeSSEClient(campaignId, res);
  });
}));

// Get live on-chain balance for a campaign
router.get('/:id/balance', asyncHandler(async (req, res) => {
  /**
   * @openapi
   * /api/campaigns/{id}/balance:
   *   get:
   *     tags: [Campaigns]
   *     summary: Get live on-chain balance for a campaign wallet
   *     parameters:
   *       - in: path
   *         name: id
   *         required: true
   *         schema: { type: string }
   *     responses:
   *       200:
   *         description: OK
   *         content:
   *           application/json:
   *             schema:
   *               type: array
   *               items:
   *                 type: object
   *                 properties:
   *                   asset_type: { type: string }
   *                   balance: { type: string }
   *       404:
   *         description: Campaign not found
   */
  const { rows } = await db.query(
    'SELECT wallet_public_key FROM campaigns WHERE id = $1',
    [req.params.id]
  );
  if (!rows.length) return res.status(404).json({ error: 'Campaign not found' });
  const balance = await getCampaignBalance(rows[0].wallet_public_key);
  res.json(balance);
}));

// Scheduled endpoint to fail expired campaigns and prevent further contributions
router.post('/cron/fail-expired', requireAuth, requireRole('admin'), asyncHandler(async (req, res) => {
  const { failed, funded } = await refreshActiveCampaignStatuses();
  res.json({ failedCampaigns: failed, fundedCampaigns: funded });
}));

// Scheduled endpoint to send 48h deadline reminders
router.post('/cron/reminders', requireAuth, requireRole('admin'), asyncHandler(async (req, res) => {
  // Find campaigns ending in exactly 2 days that are still active
  const { rows } = await db.query(
    `SELECT c.id, c.title, c.deadline, u.email as creator_email
     FROM campaigns c
     JOIN users u ON c.creator_id = u.id
     WHERE c.status = 'active'
       AND c.deadline = CURRENT_DATE + INTERVAL '2 days'`
  );

  for (const campaign of rows) {
    sendEmail({
      to: campaign.creator_email,
      subject: `Reminder: Campaign "${campaign.title}" ends in 48 hours`,
      text: `Your campaign "${campaign.title}" is approaching its deadline on ${new Date(campaign.deadline).toDateString()}. 
If your target is reached, you can request a withdrawal. Otherwise, contributions will be refunded.`
    });
  }

  res.json({ remindersSent: rows.length });
}));

// Trigger refund withdrawal requests for a failed campaign
router.post('/:id/trigger-refunds', requireAuth, requireRole('admin'), asyncHandler(async (req, res) => {
  const campaignId = req.params.id;
  const { rows: campaigns } = await db.query(
    `SELECT id, wallet_public_key, status FROM campaigns WHERE id = $1`,
    [campaignId]
  );
  if (!campaigns.length) return res.status(404).json({ error: 'Campaign not found' });
  const campaign = campaigns[0];
  if (campaign.status !== 'failed') {
    return res.status(409).json({ error: 'Refunds may only be triggered for failed campaigns' });
  }

  try {
    const { refundsCreated, refunds } = await queueFailedCampaignRefunds(campaignId, req.user.userId);
    if (refundsCreated === 0) {
      return res.json({ refundsCreated: 0 });
    }
    res.status(201).json({ refundsCreated, refunds });
  } catch (err) {
    logger.error('Refund trigger failed', { campaign_id: campaignId, error: err.message });
    res.status(500).json({ error: 'Could not trigger refunds for campaign' });
  }
}));

// Check if draft campaign is a duplicate
router.post('/check-duplicate', requireAuth, requireRole('creator', 'admin'), asyncHandler(async (req, res) => {
  const { title, description } = req.body;
  if (!title) return res.json({ isDuplicate: false });

  const contentFingerprint = getSimhash(`${title} ${description || ''}`);
  const { rows: existingCampaigns } = await db.query(
    'SELECT id, title, content_fingerprint FROM campaigns WHERE content_fingerprint IS NOT NULL AND status != $1',
    ['failed']
  );

  for (const c of existingCampaigns) {
    if (simhashSimilarity(contentFingerprint, c.content_fingerprint) > 0.9) {
      return res.json({ isDuplicate: true, similarTo: c.title });
    }
  }

  res.json({ isDuplicate: false });
}));

// Create campaign (authenticated)
router.post('/', requireAuth, requireRole('creator', 'admin'), createCampaignValidation, validateRequest, asyncHandler(async (req, res) => {
  /**
   * @openapi
   * /api/campaigns:
   *   post:
   *     tags: [Campaigns]
   *     summary: Create campaign
   *     security:
   *       - bearerAuth: []
   *     requestBody:
   *       required: true
   *       content:
   *         application/json:
   *           schema:
   *             type: object
   *             required: [title, target_amount, asset_type]
   *             properties:
   *               title: { type: string }
   *               description: { type: string, nullable: true }
   *               target_amount: { type: string }
   *               asset_type: { type: string }
   *               deadline: { type: string, nullable: true }
   *               milestones: { type: array, items: { type: object }, nullable: true }
   *               min_contribution: { type: string, nullable: true }
   *               max_contribution: { type: string, nullable: true }
   *               category: { type: string, nullable: true }
   *     responses:
   *       201:
   *         description: Created
   *       401:
   *         description: Unauthorized
   *       403:
   *         description: Forbidden
   */
  const { title, description, target_amount, asset_type, deadline, milestones, min_contribution, max_contribution, reward_tiers } = req.body;

  let normalizedMilestones;
  try {
    normalizedMilestones = normalizeMilestonesInput(milestones);
  } catch (err) {
    return res.status(400).json({ error: err.message });
  }

  // Reward tiers are optional. Validate up front (asset must match the campaign).
  let normalizedTiers;
  try {
    normalizedTiers = validateTiersInput(reward_tiers, asset_type);
  } catch (err) {
    return res.status(400).json({ error: err.message });
  }

  // Get creator's info
  const { rows: userRows } = await db.query(
    'SELECT email, wallet_public_key, kyc_status FROM users WHERE id = $1',
    [req.user.userId]
  );
  if (!userRows.length) return res.status(404).json({ error: 'User not found' });
  
  if (isKycRequiredForCampaigns() && userRows[0].kyc_status !== 'verified') {
    return res.status(403).json({
      error: 'Verify your identity before creating a campaign.',
      code: 'KYC_REQUIRED',
      kyc_status: userRows[0].kyc_status,
    });
  }

  const creatorPublicKey = userRows[0].wallet_public_key;
  const creatorEmail = userRows[0].email;

  const contentFingerprint = getSimhash(`${title} ${description || ''}`);
  let isFlaggedDuplicate = false;

  const { rows: existingCampaigns } = await db.query(
    'SELECT content_fingerprint FROM campaigns WHERE content_fingerprint IS NOT NULL AND status != $1',
    ['failed']
  );

  for (const c of existingCampaigns) {
    if (simhashSimilarity(contentFingerprint, c.content_fingerprint) > 0.9) {
      isFlaggedDuplicate = true;
      break;
    }
  }

  // 1. Create the on-chain campaign wallet
  const wallet = await createCampaignWallet(creatorPublicKey);

  // 2. Deploy Soroban contract instances
  const platformPublicKey = Keypair.fromSecret(process.env.PLATFORM_SECRET_KEY).publicKey();
  const platformFeeBps = parseInt(process.env.PLATFORM_FEE_BPS || '0', 10);
  const deadlineUnix = deadline ? Math.floor(new Date(deadline).getTime() / 1000) : 0;

  // Use a default asset contract address based on asset type. On testnet, the
  // USDC token contract address may differ from the issuer. We use the issuer
  // as a reasonable default for v1; production deployments should set
  // ASSET_CONTRACT_ADDRESS in env and populate it from the Stellar asset contract.
  const assetContractAddress = process.env.USDC_CONTRACT_ADDRESS || process.env.USDC_ISSUER;

  let escrowContractId;
  let milestonesContractId;
  let contractDeploymentStatus;
  let contractDeploymentError = null;
  try {
    ({ escrowContractId, milestonesContractId } = await deployCampaignContracts({
      creatorPublicKey,
      platformPublicKey,
      campaignId: req.body.title + Date.now(),
      targetAmount: Math.floor(parseFloat(target_amount) * 10_000_000),
      deadlineUnix,
      assetContractAddress,
      platformFeeBps,
      milestones: normalizedMilestones,
      signerSecret: process.env.PLATFORM_SECRET_KEY,
    }));
    contractDeploymentStatus = 'deployed';
  } catch (err) {
    logger.error('Soroban contract deployment failed during campaign creation', {
      error: err.message,
      creatorUserId: req.user.userId,
    });
    contractDeploymentStatus = 'failed';
    contractDeploymentError = err.message;

    Sentry.withScope((scope) => {
      scope.setLevel('error');
      scope.setTag('campaign_creation', 'contract_deployment');
      scope.setContext('deployment', {
        creatorUserId: req.user.userId,
        error: err.message,
      });
      Sentry.captureMessage(`Contract deployment failed during campaign creation: ${err.message}`);
    });
  }
  const contractAddress = escrowContractId || null;

  const client = await db.connect();
  let campaign;
  try {
    await client.query('BEGIN');
    const { rows } = await client.query(
      `INSERT INTO campaigns
         (title, description, target_amount, asset_type, wallet_public_key, creator_id, deadline, 
          min_contribution, max_contribution, escrow_contract_id, milestones_contract_id, platform_fee_bps,
          contract_address, contract_deployed_at, content_fingerprint, is_flagged_duplicate,
          contract_deployment_status, contract_deployment_error, last_deployment_attempt_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19)
       RETURNING *`,
      [title, description, target_amount, asset_type, wallet.publicKey, req.user.userId, deadline, 
       min_contribution || null, max_contribution || null, escrowContractId, milestonesContractId, platformFeeBps,
       contractAddress, contractDeploymentStatus === 'deployed' ? new Date() : null,
       contentFingerprint, isFlaggedDuplicate,
       contractDeploymentStatus, contractDeploymentError, new Date()]
    );
    campaign = rows[0];

    await client.query(
      `INSERT INTO campaign_members
         (campaign_id, user_id, email, role, accepted_at)
       VALUES ($1, $2, $3, $4, NOW())`,
      [campaign.id, req.user.userId, creatorEmail, 'owner']
    );

    for (const milestone of normalizedMilestones) {
      await client.query(
        `INSERT INTO milestones
           (campaign_id, title, description, release_percentage, sort_order)
         VALUES ($1, $2, $3, $4, $5)`,
        [
          campaign.id,
          milestone.title,
          milestone.description,
          milestone.release_percentage,
          milestone.sort_order,
        ]
      );
    }

    if (normalizedTiers.length) {
      await insertTiers(client, campaign.id, normalizedTiers);
    }

    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK');
    logger.error('[campaigns] DB insert failed after wallet creation. Orphaned wallet:', {
      publicKey: wallet.publicKey,
      creatorUserId: req.user.userId,
      error: err.message,
    });
    return res.status(500).json({
      error: 'Campaign could not be saved. Wallet creation may have succeeded — contact support.',
    });
  } finally {
    client.release();
  }

  watchCampaignWallet(campaign.id, wallet.publicKey);

  res.status(201).json(campaign);
}));

/**
 * @openapi
 * /api/campaigns/{id}/tiers:
 *   get:
 *     tags: [Campaigns]
 *     summary: List a campaign's reward tiers with remaining availability
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: List of reward tiers }
 *       404: { description: Campaign not found }
 */
router.get('/:id/tiers', asyncHandler(async (req, res) => {
  const { rows } = await db.query('SELECT id FROM campaigns WHERE id = $1', [req.params.id]);
  if (!rows.length) return res.status(404).json({ error: 'Campaign not found' });
  const tiers = await listTiersWithAvailability(req.params.id);
  res.json(tiers);
}));

/**
 * @openapi
 * /api/campaigns/{id}/tiers:
 *   post:
 *     tags: [Campaigns]
 *     summary: Add one or more reward tiers to an existing campaign (creator only)
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       201: { description: Updated list of reward tiers }
 *       400: { description: Invalid input or tier cap exceeded }
 *       403: { description: Forbidden }
 *       404: { description: Campaign not found }
 */
router.post('/:id/tiers', requireAuth, requireCampaignMember('owner'), asyncHandler(async (req, res) => {
  const campaignId = req.params.id;

  const { rows: campaignRows } = await db.query('SELECT asset_type FROM campaigns WHERE id = $1', [campaignId]);
  if (!campaignRows.length) return res.status(404).json({ error: 'Campaign not found' });
  const assetType = campaignRows[0].asset_type;

  // Accept either a single tier object or an array of tiers.
  const input = Array.isArray(req.body) ? req.body : [req.body];
  let normalizedTiers;
  try {
    normalizedTiers = validateTiersInput(input, assetType);
  } catch (err) {
    return res.status(400).json({ error: err.message });
  }
  if (!normalizedTiers.length) {
    return res.status(400).json({ error: 'At least one reward tier is required' });
  }

  const { rows: countRows } = await db.query(
    'SELECT COUNT(*)::int AS n FROM reward_tiers WHERE campaign_id = $1',
    [campaignId]
  );
  if (countRows[0].n + normalizedTiers.length > MAX_TIERS_PER_CAMPAIGN) {
    return res.status(400).json({
      error: `A campaign can have at most ${MAX_TIERS_PER_CAMPAIGN} reward tiers`,
    });
  }

  const client = await db.connect();
  try {
    await client.query('BEGIN');
    await insertTiers(client, campaignId, normalizedTiers);
    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK');
    logger.error('[campaigns] add reward tiers failed', { error: err.message });
    return res.status(500).json({ error: 'Could not add reward tiers' });
  } finally {
    client.release();
  }

  const tiers = await listTiersWithAvailability(campaignId);
  res.status(201).json(tiers);
}));

// PATCH /campaigns/:id - Update campaign (title, description, deadline)
router.patch('/:id', requireAuth, asyncHandler(async (req, res) => {
  const campaignId = req.params.id;
  const { title, description, deadline } = req.body;

  // Check if campaign exists and belongs to user
  const { rows: campaignRows } = await db.query(
    'SELECT * FROM campaigns WHERE id = $1',
    [campaignId]
  );
  if (!campaignRows.length) {
    return res.status(404).json({ error: 'Campaign not found' });
  }

  const campaign = campaignRows[0];
  const userRole = await resolveUserCampaignRole(campaignId, req.user.userId, req.user.role === 'admin');
  if (!canEditCampaignContent(userRole)) {
    return res.status(403).json({ error: 'You do not have permission to edit this campaign' });
  }

  // Refresh campaign status to check current state
  await refreshCampaignStatus(campaignId);

  const { rows: updatedStatusRows } = await db.query(
    'SELECT status FROM campaigns WHERE id = $1',
    [campaignId]
  );
  const currentStatus = updatedStatusRows[0].status;

  // Only allow editing active or funded campaigns
  if (!['active', 'funded'].includes(currentStatus)) {
    return res.status(422).json({
      error: `Cannot edit a campaign with status: ${currentStatus}`
    });
  }

  // Validate and prepare update object
  const updates = {};
  const updateParams = [];
  let paramIndex = 1;

  if (title !== undefined) {
    const cleanTitle = stripHtml(title);
    if (!cleanTitle) {
      return res.status(422).json({ error: 'Title cannot be empty' });
    }
    if (cleanTitle.length > 100) {
      return res.status(422).json({ error: 'Title must be at most 100 characters' });
    }
    updates.title = cleanTitle;
    updateParams.push(['title', cleanTitle, `$${paramIndex++}`]);
  }

  if (description !== undefined) {
    const cleanDesc = stripHtml(description);
    if (cleanDesc.length > 1000) {
      return res.status(422).json({ error: 'Description must be at most 1000 characters' });
    }
    updates.description = cleanDesc;
    updateParams.push(['description', cleanDesc, `$${paramIndex++}`]);
  }

  if (deadline !== undefined && deadline !== null && deadline !== '') {
    // Validate ISO8601 format
    const deadlineDate = new Date(deadline);
    if (isNaN(deadlineDate.getTime())) {
      return res.status(422).json({ error: 'Deadline must be a valid ISO 8601 date' });
    }

    // Check deadline is not in the past (UTC comparison)
    const now = new Date();
    if (deadlineDate.getTime() <= now.getTime()) {
      return res.status(422).json({ error: 'Deadline must be in the future (UTC)' });
    }

    updates.deadline = deadline;
    updateParams.push(['deadline', deadline, `$${paramIndex++}`]);
  }

  // Check if any valid updates were provided
  if (Object.keys(updates).length === 0) {
    return res.status(400).json({ error: 'No valid fields to update' });
  }

  // Check for invalid fields in request body
  const allowedFields = ['title', 'description', 'deadline'];
  for (const field of Object.keys(req.body)) {
    if (!allowedFields.includes(field)) {
      return res.status(422).json({
        error: `Cannot update field: ${field}`
      });
    }
  }

  // Build and execute update query
  const setClause = updateParams.map(([field, , placeholder]) => `${field} = ${placeholder}`).join(', ');
  const values = updateParams.map(([, value]) => value);
  values.push(campaignId);
  values.push(currentStatus);
  const statusParamIndex = paramIndex + 1;

  const query = `
    UPDATE campaigns
    SET ${setClause}
    WHERE id = $${paramIndex} AND status = $${statusParamIndex}
    RETURNING *
  `;

  const { rows: updatedRows } = await db.query(query, values);
  if (!updatedRows.length) {
    const { rows: checkRows } = await db.query(
      'SELECT status FROM campaigns WHERE id = $1',
      [campaignId]
    );
    if (!checkRows.length) {
      return res.status(404).json({ error: 'Campaign not found' });
    }
    return res.status(422).json({
      error: `Cannot edit a campaign with status: ${checkRows[0].status}`,
    });
  }

  res.json(updatedRows[0]);
}));

router.post(
  '/:id/cover-image',
  requireAuth,
  requireCampaignMember('owner', 'editor'),
  (req, res, next) => {
    upload.single('cover_image')(req, res, (err) => {
      if (err) {
        return res.status(422).json({
          error: {
            code: 'VALIDATION_ERROR',
            message: err.message || 'Invalid cover image upload',
            fields: { cover_image: err.message || 'Invalid file' },
          },
        });
      }
      next();
    });
  },
  async (req, res) => {
    if (!req.file) {
      return res.status(422).json({
        error: {
          code: 'VALIDATION_ERROR',
          message: 'cover_image is required',
          fields: { cover_image: 'No image uploaded' },
        },
      });
    }

    try {
      const coverImageUrl = await uploadCampaignCoverImage(req.params.id, req.file);
      const { rows: updatedRows } = await db.query(
        'UPDATE campaigns SET cover_image_url = $1 WHERE id = $2 RETURNING *',
        [coverImageUrl, req.params.id]
      );
      res.json(updatedRows[0]);
    } catch (err) {
      return res.status(500).json({ error: 'Could not upload campaign cover image' });
    }
  }
);

router.get('/:id/updates', asyncHandler(async (req, res) => {
  const limit = Math.min(50, Math.max(1, Number(req.query.limit) || 10));
  const offset = Math.max(0, Number(req.query.offset) || 0);
  const { rows } = await db.query(
    `SELECT cu.id, cu.campaign_id, cu.author_id, cu.title, cu.body, cu.created_at, u.name AS author_name
     FROM campaign_updates cu
     JOIN users u ON u.id = cu.author_id
     WHERE cu.campaign_id = $1
     ORDER BY cu.created_at DESC
     LIMIT $2 OFFSET $3`,
    [req.params.id, limit, offset]
  );
  res.json(rows);
}));

router.post('/:id/updates', requireAuth, requireCampaignMember('owner', 'manager'), createCampaignUpdateValidation, validateRequest, asyncHandler(async (req, res) => {
  const { title, body } = req.body;

  const { rows } = await db.query(
    `INSERT INTO campaign_updates (campaign_id, author_id, title, body)
     VALUES ($1, $2, $3, $4)
     RETURNING id, campaign_id, author_id, title, body, created_at`,
    [req.params.id, req.user.userId, title.trim(), body.trim()]
  );
  res.status(201).json(rows[0]);
}));

// POST /campaigns/:id/members/invite — owner/manager invites by email (7-day token)
router.post('/:id/members/invite', requireAuth, requireCampaignMember('owner', 'manager'), asyncHandler(async (req, res) => {
  const { email, role } = req.body;
  if (!email || !role) return res.status(422).json({ error: 'Email and role are required' });
  if (!isValidRole(role)) {
    return res.status(422).json({ error: 'Invalid role. Must be owner, manager, editor, or viewer' });
  }

  const { rows: campaignRows } = await db.query('SELECT title FROM campaigns WHERE id = $1', [req.params.id]);
  const { member } = await createCampaignInvite({
    campaignId: req.params.id,
    email,
    role,
    invitedByUserId: req.user.userId,
    campaignTitle: campaignRows[0]?.title,
  });
  res.status(201).json(member);
}));

// GET /campaigns/:id/members — team list (owner/manager)
router.get('/:id/members', requireAuth, requireCampaignMember('owner', 'manager'), asyncHandler(async (req, res) => {
  const { limit, offset } = parsePagination(req.query, { limit: 20, max: 100 });

  const countResult = await db.query(
    'SELECT COUNT(*)::int AS total FROM campaign_members WHERE campaign_id = $1',
    [req.params.id]
  );
  const total = countResult.rows[0].total;

  const { rows } = await db.query(
    `SELECT cm.id, cm.user_id, cm.email, cm.role, cm.accepted_at, cm.created_at,
            cm.invite_expires_at,
            u.name AS user_name
     FROM campaign_members cm
     LEFT JOIN users u ON u.id = cm.user_id
     WHERE cm.campaign_id = $1
     ORDER BY cm.created_at ASC
     LIMIT $2 OFFSET $3`,
    [req.params.id, limit, offset]
  );
  res.json({ data: rows, total, limit, offset });
}));

// PATCH /campaigns/:id/members/:userId — change role (owner only)
router.patch('/:id/members/:userId', requireAuth, requireCampaignMember('owner'), asyncHandler(async (req, res) => {
  const { role } = req.body;
  if (!role || !isValidRole(role)) {
    return res.status(422).json({ error: 'Invalid role. Must be owner, manager, editor, or viewer' });
  }

  const { rows } = await db.query(
    `UPDATE campaign_members
     SET role = $1
     WHERE campaign_id = $2 AND user_id = $3 AND accepted_at IS NOT NULL
     RETURNING id, campaign_id, user_id, role, accepted_at`,
    [role, req.params.id, req.params.userId]
  );

  if (!rows.length) {
    return res.status(404).json({ error: 'Member not found' });
  }

  res.json(rows[0]);
}));

// POST /campaigns/:id/members/:memberId/resend — resend pending invite
router.post('/:id/members/:memberId/resend', requireAuth, requireCampaignMember('owner', 'manager'), asyncHandler(async (req, res) => {
  const { rows: campaignRows } = await db.query('SELECT title FROM campaigns WHERE id = $1', [req.params.id]);
  const { member } = await resendCampaignInvite({
    memberId: req.params.memberId,
    campaignId: req.params.id,
    campaignTitle: campaignRows[0]?.title,
  });
  res.json(member);
}));

// DELETE /campaigns/:id/members/invites/:memberId — cancel pending invite
router.delete('/:id/members/invites/:memberId', requireAuth, requireCampaignMember('owner', 'manager'), asyncHandler(async (req, res) => {
  await cancelCampaignInvite({
    memberId: req.params.memberId,
    campaignId: req.params.id,
  });
  res.json({ cancelled: true });
}));

// DELETE /campaigns/:id/members/:userId — remove member (owner) or leave team
router.delete('/:id/members/:userId', requireAuth, asyncHandler(async (req, res) => {
  const memberUserId = req.params.userId;
  const isSelf = String(memberUserId) === String(req.user.userId);

  const actorRole = await resolveUserCampaignRole(
    req.params.id,
    req.user.userId,
    req.user.role === 'admin'
  );

  if (!isSelf && !canManageMembers(actorRole)) {
    return res.status(403).json({ error: 'Insufficient permissions' });
  }

  const { rows: targetRows } = await db.query(
    `SELECT role, accepted_at FROM campaign_members
     WHERE campaign_id = $1 AND user_id = $2`,
    [req.params.id, memberUserId]
  );

  if (!targetRows.length) {
    return res.status(404).json({ error: 'Member not found' });
  }

  if (targetRows[0].role === 'owner' && targetRows[0].accepted_at) {
    const ownerCount = await countAcceptedOwners(req.params.id);
    if (ownerCount <= 1) {
      return res.status(409).json({ error: 'Cannot remove the last owner from the campaign team' });
    }
  }

  const { rows } = await db.query(
    `DELETE FROM campaign_members
     WHERE campaign_id = $1 AND user_id = $2
     RETURNING id`,
    [req.params.id, memberUserId]
  );

  res.json({ message: 'Member removed successfully', id: rows[0].id });
}));

// POST /campaigns/:id/members/accept — accept invitation (token in body, legacy)
router.post('/:id/members/accept', requireAuth, asyncHandler(async (req, res) => {
  const { token: inviteToken } = req.body;
  if (!inviteToken) return res.status(422).json({ error: 'Invitation token is required' });

  const { rows: userRows } = await db.query('SELECT email FROM users WHERE id = $1', [req.user.userId]);
  const member = await acceptCampaignInvite({
    inviteToken,
    userId: req.user.userId,
    userEmail: userRows[0]?.email,
  });
  res.json(member);
}));

const { getCampaignAnalytics, getCampaignContributors, getCampaignBackers } = require('../services/analyticsService');
// PATCH /campaigns/:id/visibility — toggle is_hidden for a campaign (owner or admin only)
router.patch('/:id/visibility', requireAuth, asyncHandler(async (req, res) => {
  const campaignId = req.params.id;

  const { rows: campaignRows } = await db.query(
    'SELECT * FROM campaigns WHERE id = $1',
    [campaignId]
  );
  if (!campaignRows.length) {
    return res.status(404).json({ error: 'Campaign not found' });
  }

  const campaign = campaignRows[0];
  const userRole = await resolveUserCampaignRole(campaignId, req.user.userId, req.user.role === 'admin');

  if (userRole !== 'owner') {
    return res.status(403).json({ error: 'Only the campaign owner can change visibility' });
  }

  const newHidden = req.body.is_hidden;
  if (typeof newHidden !== 'boolean') {
    return res.status(422).json({ error: 'is_hidden must be a boolean' });
  }

  const { rows: updatedRows } = await db.query(
    'UPDATE campaigns SET is_hidden = $1 WHERE id = $2 RETURNING *',
    [newHidden, campaignId]
  );

  // Log to admin_actions for audit trail
  try {
    await db.query(
      `INSERT INTO admin_actions (admin_user_id, action_type, target_type, target_id, details)
       VALUES ($1, $2, $3, $4, $5::jsonb)`,
      [
        req.user.userId,
        newHidden ? 'campaign_hidden' : 'campaign_unhidden',
        'campaign',
        campaignId,
        JSON.stringify({
          campaign_title: campaign.title,
          previous_is_hidden: campaign.is_hidden,
          new_is_hidden: newHidden,
        }),
      ]
    );
  } catch (err) {
    logger.warn('Failed to log visibility change to admin_actions', {
      campaign_id: campaignId,
      error: err.message,
    });
  }

  res.json({ is_hidden: updatedRows[0].is_hidden });
}));

// GET /campaigns/:id/analytics — full contribution analytics
router.get('/:id/analytics', asyncHandler(async (req, res) => {
  const data = await getCampaignAnalytics(req.params.id);
  if (!data) return res.status(404).json({ error: 'Campaign not found' });
  res.json(data);
}));

// GET /campaigns/:id/analytics/contributors — country breakdown, repeat vs first-time
router.get('/:id/analytics/contributors', requireAuth, asyncHandler(async (req, res) => {
  // verify campaign exists and requester is owner or admin
  const { rows } = await db.query('SELECT creator_id FROM campaigns WHERE id = $1', [req.params.id]);
  if (!rows.length) return res.status(404).json({ error: 'Campaign not found' });
  if (req.user.role !== 'admin' && rows[0].creator_id !== req.user.userId) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  const data = await getCampaignContributors(req.params.id);
  res.json(data);
}));

// GET /campaigns/:id/analytics/backers — backer growth, leaderboard, repeat rate
router.get('/:id/analytics/backers', requireAuth, asyncHandler(async (req, res) => {
  const { rows } = await db.query('SELECT creator_id FROM campaigns WHERE id = $1', [req.params.id]);
  if (!rows.length) return res.status(404).json({ error: 'Campaign not found' });
  if (req.user.role !== 'admin' && rows[0].creator_id !== req.user.userId) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  const data = await getCampaignBackers(req.params.id);
  res.json(data);
}));

// GET /campaigns/:id/referral — get or create a referral code for the authenticated user
router.get('/:id/referral', requireAuth, asyncHandler(async (req, res) => {
  const { rows: existing } = await db.query(
    `SELECT cr.id, cr.referral_code, cr.click_count, cr.contribution_count
     FROM campaign_referrals cr
     WHERE cr.campaign_id = $1 AND cr.referrer_user_id = $2`,
    [req.params.id, req.user.userId]
  );

  if (existing.length) {
    const row = existing[0];
    return res.json({
      referral_code: row.referral_code,
      referral_url: `${process.env.FRONTEND_URL || 'http://localhost:5173'}/campaigns/${req.params.id}?ref=${row.referral_code}`,
      click_count: row.click_count,
      contribution_count: row.contribution_count,
    });
  }

  const code = await generateUniqueReferralCode(db);
  const { rows: inserted } = await db.query(
    `INSERT INTO campaign_referrals (campaign_id, referrer_user_id, referral_code)
     VALUES ($1, $2, $3)
     RETURNING referral_code, click_count, contribution_count`,
    [req.params.id, req.user.userId, code]
  );
  const row = inserted[0];
  res.status(201).json({
    referral_code: row.referral_code,
    referral_url: `${process.env.FRONTEND_URL || 'http://localhost:5173'}/campaigns/${req.params.id}?ref=${row.referral_code}`,
    click_count: row.click_count,
    contribution_count: row.contribution_count,
  });
}));

// GET /campaigns/:id/referrals — creator only; list top referrers
router.get('/:id/referrals', requireAuth, requireCampaignMember('owner'), asyncHandler(async (req, res) => {
  const { rows } = await db.query(
    `SELECT cr.referral_code, cr.click_count, cr.contribution_count, cr.created_at,
            u.name AS referrer_name, u.id AS referrer_id
     FROM campaign_referrals cr
     JOIN users u ON u.id = cr.referrer_user_id
     WHERE cr.campaign_id = $1
     ORDER BY cr.contribution_count DESC, cr.click_count DESC`,
    [req.params.id]
  );
  res.json(rows);
}));

module.exports = router;
