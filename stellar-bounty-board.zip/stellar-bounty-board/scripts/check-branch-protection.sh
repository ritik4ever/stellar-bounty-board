#!/usr/bin/env bash
# check-branch-protection.sh
#
# Verifies that the branch protection settings on `main` match the policy
# documented in docs/branch-protection.md.
#
# Usage:
#   ./scripts/check-branch-protection.sh <owner> <repo>
#
# Examples:
#   ./scripts/check-branch-protection.sh ritik4ever stellar-bounty-board
#
# Prerequisites:
#   - gh CLI installed and authenticated (gh auth login)
#     Minimum scope required: read:repo  (public repos need no auth at all
#     for most fields, but enforce_admins requires authentication)
#   - jq installed (https://stedolan.github.io/jq/)
#
# Exit codes:
#   0  All settings match the documented policy
#   1  One or more settings are out of spec (details printed to stdout)
#   2  Usage error or missing dependency

set -euo pipefail

# ── colours ────────────────────────────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BOLD='\033[1m'
RESET='\033[0m'

pass() { echo -e "  ${GREEN}✓${RESET}  $*"; }
fail() { echo -e "  ${RED}✗${RESET}  $*"; FAILURES=$((FAILURES + 1)); }
warn() { echo -e "  ${YELLOW}!${RESET}  $*"; }
header() { echo -e "\n${BOLD}$*${RESET}"; }

# ── arg / dependency checks ────────────────────────────────────────────────────
if [[ $# -lt 2 ]]; then
  echo "Usage: $0 <owner> <repo>" >&2
  exit 2
fi

OWNER="$1"
REPO="$2"
BRANCH="main"
FAILURES=0

for cmd in gh jq; do
  if ! command -v "$cmd" &>/dev/null; then
    echo -e "${RED}Error:${RESET} '$cmd' is not installed or not on PATH." >&2
    echo "  gh  → https://cli.github.com/" >&2
    echo "  jq  → https://stedolan.github.io/jq/" >&2
    exit 2
  fi
done

# ── fetch live settings ────────────────────────────────────────────────────────
echo -e "\n${BOLD}Checking branch protection for ${OWNER}/${REPO}:${BRANCH}${RESET}"
echo "Fetching settings via GitHub API …"

if ! PROTECTION=$(gh api \
    -H "Accept: application/vnd.github+json" \
    "/repos/${OWNER}/${REPO}/branches/${BRANCH}/protection" 2>&1); then
  echo -e "${RED}Error:${RESET} Could not fetch branch protection settings." >&2
  echo "$PROTECTION" >&2
  echo "" >&2
  echo "Possible causes:" >&2
  echo "  • Branch protection is not configured on '${BRANCH}'" >&2
  echo "  • You are not authenticated: run 'gh auth login'" >&2
  echo "  • The repository or branch name is wrong" >&2
  exit 1
fi

# ── expected required status checks ───────────────────────────────────────────
# These names must match the `jobs.<id>.name` values in each workflow file.
# See docs/branch-protection.md for the mapping table.
EXPECTED_CHECKS=(
  "Backend lint, type-check, test and coverage"
  "Frontend lint, type-check and tests"
  "Contract audit and build"
  "Frontend – Type-check, Lint, Test & Build"
  "Soroban contract: clippy & test"
  "Analyze (javascript)"
  "check"
)

# ── 1. pull request reviews ────────────────────────────────────────────────────
header "1. Pull request reviews"

PR_REVIEWS=$(echo "$PROTECTION" | jq -r '.required_pull_request_reviews // empty')

if [[ -z "$PR_REVIEWS" ]]; then
  fail "required_pull_request_reviews block is missing — PRs are not required"
else
  # 1a. required approving reviewers
  APPROVALS=$(echo "$PR_REVIEWS" | jq -r '.required_approving_review_count // 0')
  if [[ "$APPROVALS" -ge 1 ]]; then
    pass "required_approving_review_count = ${APPROVALS} (expected ≥ 1)"
  else
    fail "required_approving_review_count = ${APPROVALS} (expected ≥ 1)"
  fi

  # 1b. dismiss stale reviews
  DISMISS=$(echo "$PR_REVIEWS" | jq -r '.dismiss_stale_reviews // false')
  if [[ "$DISMISS" == "true" ]]; then
    pass "dismiss_stale_reviews = true"
  else
    fail "dismiss_stale_reviews = ${DISMISS} (expected true)"
  fi
fi

# ── 2. required status checks ─────────────────────────────────────────────────
header "2. Required status checks"

STATUS_CHECKS=$(echo "$PROTECTION" | jq -r '.required_status_checks // empty')

if [[ -z "$STATUS_CHECKS" ]]; then
  fail "required_status_checks block is missing — no status checks are required"
else
  # 2a. strict (branches must be up to date)
  STRICT=$(echo "$STATUS_CHECKS" | jq -r '.strict // false')
  if [[ "$STRICT" == "true" ]]; then
    pass "strict (up-to-date branch) = true"
  else
    fail "strict = ${STRICT} (expected true)"
  fi

  # 2b. each expected check is present
  LIVE_CHECKS=$(echo "$STATUS_CHECKS" | jq -r '[.contexts[], (.checks[]?.context // empty)] | unique | .[]' 2>/dev/null || true)

  for expected in "${EXPECTED_CHECKS[@]}"; do
    if echo "$LIVE_CHECKS" | grep -qF "$expected"; then
      pass "status check present: '${expected}'"
    else
      fail "status check MISSING: '${expected}'"
    fi
  done

  # 2c. warn about unexpected checks (not a failure, just informational)
  while IFS= read -r live_check; do
    [[ -z "$live_check" ]] && continue
    found=false
    for expected in "${EXPECTED_CHECKS[@]}"; do
      [[ "$live_check" == "$expected" ]] && found=true && break
    done
    if [[ "$found" == "false" ]]; then
      warn "Undocumented status check found: '${live_check}' — consider adding it to docs/branch-protection.md"
    fi
  done <<< "$LIVE_CHECKS"
fi

# ── 3. enforce admins ─────────────────────────────────────────────────────────
header "3. Enforce rules for admins"

ENFORCE=$(echo "$PROTECTION" | jq -r '.enforce_admins.enabled // false')
if [[ "$ENFORCE" == "true" ]]; then
  pass "enforce_admins = true (admins cannot bypass rules)"
else
  fail "enforce_admins = ${ENFORCE} (expected true — admins should not bypass rules)"
fi

# ── 4. conversation resolution ────────────────────────────────────────────────
header "4. Require conversation resolution"

CONV_RES=$(echo "$PROTECTION" | jq -r '.required_conversation_resolution.enabled // false')
if [[ "$CONV_RES" == "true" ]]; then
  pass "required_conversation_resolution = true"
else
  fail "required_conversation_resolution = ${CONV_RES} (expected true)"
fi

# ── 5. linear history ─────────────────────────────────────────────────────────
header "5. Require linear history"

LINEAR=$(echo "$PROTECTION" | jq -r '.required_linear_history.enabled // false')
if [[ "$LINEAR" == "true" ]]; then
  pass "required_linear_history = true"
else
  fail "required_linear_history = ${LINEAR} (expected true)"
fi

# ── 6. force pushes and deletions ─────────────────────────────────────────────
header "6. Force pushes and deletions"

FORCE=$(echo "$PROTECTION" | jq -r '.allow_force_pushes.enabled // false')
if [[ "$FORCE" == "false" ]]; then
  pass "allow_force_pushes = false"
else
  fail "allow_force_pushes = ${FORCE} (expected false)"
fi

DELETE=$(echo "$PROTECTION" | jq -r '.allow_deletions.enabled // false')
if [[ "$DELETE" == "false" ]]; then
  pass "allow_deletions = false"
else
  fail "allow_deletions = ${DELETE} (expected false)"
fi

# ── summary ───────────────────────────────────────────────────────────────────
echo ""
echo "────────────────────────────────────────────────────────────"
if [[ "$FAILURES" -eq 0 ]]; then
  echo -e "${GREEN}${BOLD}All checks passed.${RESET} Branch protection matches the documented policy."
  echo "See docs/branch-protection.md for the full policy reference."
  exit 0
else
  echo -e "${RED}${BOLD}${FAILURES} check(s) failed.${RESET} Branch protection does not match the documented policy."
  echo ""
  echo "To apply the correct settings, see the 'Applying these settings manually'"
  echo "section in docs/branch-protection.md, or run the gh api command documented there."
  exit 1
fi
