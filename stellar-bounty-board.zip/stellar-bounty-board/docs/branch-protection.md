# Branch Protection Policy

This document describes the branch protection rules enforced on the `main` branch of
`ritik4ever/stellar-bounty-board`, explains why each rule exists, and provides a
verification command you can run to confirm the live settings match this policy.

> **Note:** GitHub branch protection rules cannot be stored as workflow files or committed
> code — they live in repository settings and must be applied manually by a repo admin
> (or via the GitHub API / `gh` CLI). This document acts as the source of truth. If the
> live settings drift from what is documented here, the verification script will tell you.

---

## Protected branch: `main`

### 1. Require a pull request before merging

| Setting | Value |
|---|---|
| Require pull request | **enabled** |
| Required approving reviewers | **1** |
| Dismiss stale reviews on new push | **enabled** |
| Require review from code owners | **disabled** (no CODEOWNERS file present) |

All changes to `main` must go through a pull request. Direct pushes are blocked.
Stale approvals are dismissed automatically so that approvers always review the final
diff, not an earlier version.

### 2. Require status checks to pass before merging

| Setting | Value |
|---|---|
| Require status checks | **enabled** |
| Require branches to be up to date | **enabled** |

The following CI jobs are required to pass on every pull request targeting `main`:

| Status check name | Source workflow | What it validates |
|---|---|---|
| `Backend lint, type-check, test and coverage` | `ci.yml` | TypeScript typecheck, ESLint, Vitest tests + coverage for the backend |
| `Frontend lint, type-check and tests` | `ci.yml` | TypeScript typecheck, ESLint, Vitest tests + Storybook build for the frontend |
| `Contract audit and build` | `ci.yml` | `cargo audit`, Soroban WASM build |
| `Frontend – Type-check, Lint, Test & Build` | `frontend-ci.yml` | Standalone frontend pipeline (typecheck, lint, Vitest with coverage, `vite build`) |
| `Soroban contract: clippy & test` | `soroban-contract-ci.yml` | `cargo clippy -D warnings`, `cargo test`, WASM release build |
| `Analyze (javascript)` | `codeql.yml` | CodeQL static analysis (security-extended + security-and-quality queries) |
| `check` | `pr-check.yml` | Root-level build typecheck and test suite |

> **How status check names are determined:** The name shown in branch protection settings
> matches the `jobs.<id>.name` field in each workflow file. If a job has no explicit
> `name`, GitHub uses the job id. The names listed above come from the `name:` keys in
> each workflow.

### 3. Require conversation resolution before merging

| Setting | Value |
|---|---|
| Require all conversations resolved | **enabled** |

Every review comment thread must be resolved before the merge button becomes available.
This prevents accidentally shipping feedback that was left open.

### 4. Require linear history

| Setting | Value |
|---|---|
| Require linear history | **enabled** |

Merge commits are not allowed on `main`. All PRs must be squash-merged or rebase-merged.
This keeps `git log` clean and bisectable.

### 5. Do not allow bypassing the above settings

| Setting | Value |
|---|---|
| Allow bypassing | **disabled** |

Even repository admins are subject to the rules above. There is no fast-lane to skip CI
or the review requirement.

### 6. Restrict force pushes and deletions

| Setting | Value |
|---|---|
| Allow force pushes | **disabled** |
| Allow deletions | **disabled** |

`main` cannot be force-pushed or deleted by anyone.

---

## Applying these settings manually

Branch protection rules are configured under:

**Repository → Settings → Branches → Branch protection rules → Edit (`main`)**

Use the table above as a checklist when creating a fresh fork or after a repo transfer
resets settings.

Alternatively, apply them programmatically with the `gh` CLI (requires `admin:repo`
scope and `gh auth login`):

```bash
gh api \
  --method PUT \
  -H "Accept: application/vnd.github+json" \
  /repos/{owner}/{repo}/branches/main/protection \
  --input - <<'EOF'
{
  "required_status_checks": {
    "strict": true,
    "contexts": [
      "Backend lint, type-check, test and coverage",
      "Frontend lint, type-check and tests",
      "Contract audit and build",
      "Frontend – Type-check, Lint, Test & Build",
      "Soroban contract: clippy & test",
      "Analyze (javascript)",
      "check"
    ]
  },
  "enforce_admins": true,
  "required_pull_request_reviews": {
    "dismiss_stale_reviews": true,
    "require_code_owner_reviews": false,
    "required_approving_review_count": 1
  },
  "required_conversation_resolution": true,
  "required_linear_history": true,
  "allow_force_pushes": false,
  "allow_deletions": false,
  "block_creations": false
}
EOF
```

Replace `{owner}` and `{repo}` with the actual values (e.g. `ritik4ever` and
`stellar-bounty-board`).

---

## Verifying settings match this policy

The `scripts/check-branch-protection.sh` script reads the live branch protection settings
via the GitHub API and compares them against the policy above.

```bash
# Prerequisite: gh CLI authenticated with read:repo scope
./scripts/check-branch-protection.sh ritik4ever stellar-bounty-board
```

See [scripts/check-branch-protection.sh](../scripts/check-branch-protection.sh) for the
full source. A passing run exits with code `0` and prints a green summary. Any drift
exits with code `1` and prints exactly which settings are out of spec.

---

## Limitations and manual steps

GitHub does not expose all branch protection settings through workflow files or committed
configuration. The following items **cannot** be enforced via CI and require a human admin
to configure in repository settings:

| Item | Why it is manual |
|---|---|
| Branch protection rules themselves | The GitHub API endpoint that writes protection rules requires `admin:repo` scope — a secret that should not be stored in general-purpose CI secrets for security reasons |
| Restricting push access to specific teams/users | Requires organisation-level team membership, which is not available in forked contributor environments |
| Requiring signed commits | Per-user GPG/SSH key configuration; cannot be automated across contributors |

The `check-branch-protection.sh` script covers everything that is readable via the
unauthenticated or `read:repo`-scoped API and will flag any divergence from this document.

---

## Related documentation

- [CONTRIBUTING.md](../CONTRIBUTING.md) — pull request checklist and commit conventions
- [docs/ARCHITECTURE.md](ARCHITECTURE.md) — system architecture and data flow
- [.github/workflows/ci.yml](../.github/workflows/ci.yml) — primary CI pipeline
- [.github/workflows/frontend-ci.yml](../.github/workflows/frontend-ci.yml) — frontend standalone CI
- [.github/workflows/soroban-contract-ci.yml](../.github/workflows/soroban-contract-ci.yml) — Soroban contract CI
- [.github/workflows/codeql.yml](../.github/workflows/codeql.yml) — CodeQL security analysis
- [.github/workflows/pr-check.yml](../.github/workflows/pr-check.yml) — PR typecheck and test gate
